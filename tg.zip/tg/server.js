const { TelegramClient } = require('telegram');
const { StringSession } = require('telegram/sessions');
const input = require('input');
const express = require('express');
const fs = require('fs');

const apiId = 27451332;
const apiHash = '1462d961e4a7bf6b5139309255f09fd6';

// Сохраняем сессию прямо на флешку, чтобы не терялась
const sessionPath = '/sdcard/tg/session.txt';
let sessionString = '';
if (fs.existsSync(sessionPath)) {
    sessionString = fs.readFileSync(sessionPath, 'utf8');
}

// МАКСИМАЛЬНАЯ МАСКИРОВКА под официальный Telegram Desktop
const client = new TelegramClient(new StringSession(sessionString), apiId, apiHash, {
    connectionRetries: 5,
    deviceModel: "Desktop",
    systemVersion: "Windows 10",
    appVersion: "4.15.0",
    langCode: "ru",
    systemLangCode: "ru",
});

const app = express();

// Раздаем файлы с флешки
app.use(express.static('/sdcard/tg/public'));

app.get('/api/feed', async (req, res) => {
    try {
        console.log("Браузер запросил ленту...");
        const dialogs = await client.getDialogs({});
        const channels = dialogs.filter(d => d.isChannel);
        
        let allPosts = [];
        for (const channel of channels.slice(0, 15)) {
            try {
                const messages = await client.getMessages(channel.entity, { limit: 5 });
                messages.forEach(msg => {
                    if (msg.message) {
                        allPosts.push({
                            id: msg.id,
                            text: msg.message,
                            date: msg.date,
                            channelTitle: msg.chat ? msg.chat.title : "Канал"
                        });
                    }
                });
            } catch (e) {}
        }
        allPosts.sort((a, b) => b.date - a.date);
        res.json(allPosts);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

(async () => {
    console.log("Подключение к серверам Telegram...");
    
    try {
        await client.start({
            phoneNumber: async () => await input.text("📱 Введите номер телефона (ОБЯЗАТЕЛЬНО С +7): "),
            password: async () => await input.text("🔑 Введите пароль (если есть, иначе Enter): "),
            phoneCode: async () => await input.text("💬 Введите код из официального Telegram: "),
            onError: (err) => console.log("Ошибка: ", err.message),
        });

        console.log("✅ Успешная авторизация!");
        fs.writeFileSync(sessionPath, client.session.save());

        // Изменили порт на 8081
        app.listen(8081, '0.0.0.0', () => {
            console.log("=========================================");
            console.log("🚀 Сервер запущен!");
            console.log("Открой в браузере: http://localhost:8081");
            console.log("=========================================");
        });
    } catch (e) {
        console.error("Критическая ошибка запуска:", e);
    }
})();
